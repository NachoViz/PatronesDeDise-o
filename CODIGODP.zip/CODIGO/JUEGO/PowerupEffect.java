// PowerupEffect.java
public interface PowerupEffect {
    void applyEffect(Personaje personaje);
}