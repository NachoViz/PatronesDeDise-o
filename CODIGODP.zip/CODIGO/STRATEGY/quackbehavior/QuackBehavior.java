package quackbehavior;
public interface QuackBehavior {
    void quack();
}