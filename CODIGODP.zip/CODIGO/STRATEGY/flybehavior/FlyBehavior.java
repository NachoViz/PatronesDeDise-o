package flybehavior;
public interface FlyBehavior {
    void fly();
}